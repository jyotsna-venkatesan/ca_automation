package org.CATests.pageObjects.android;

import org.CATests.pageObjects.android.AbstractPageClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class HomePage extends AbstractPageClass {

    // set up the driver for this page
    public HomePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }


    // buttons:
    // transport page button, in case if it is not opened already
    @AndroidFindBy(xpath = "(//android.widget.TextView[@text=\"Transport\"])[1]")
    private WebElement buttonToTransportPage;


    // methods:
    // method to click on the button
    public boolean clickTransportButton() {
        try {
            WebElement buttonToTransportPageVisible = waitForVisibility(buttonToTransportPage);
            buttonToTransportPageVisible.click();
            return true;
        } catch (Exception e) {
            System.out.println("Error clicking the transport button: " + e.getMessage());
            return false;
        }
    }


}
