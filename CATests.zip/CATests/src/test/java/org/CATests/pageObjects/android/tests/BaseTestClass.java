package org.CATests.pageObjects.android.tests;

import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import java.net.MalformedURLException;
import java.net.URL;

// testNG imports
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

// import the pages to automate it
import org.CATests.pageObjects.android.tests.transport.AddressPageTest;
import org.CATests.pageObjects.android.tests.transport.TimeAndVehiclePageTest;
import org.CATests.pageObjects.android.tests.transport.OrderDetailsPageTest;



public class BaseTestClass {

    static AppiumDriver driver;

    public static void main(String[] args){
        try {
            openMobileApp();
            // home page
            HomePageTest homePageTest = new HomePageTest(driver);
            homePageTest.testAutomateTheHomePage();

            // address page
            AddressPageTest addressPageTest = new AddressPageTest(driver);
            addressPageTest.testAutomateTheAddressPage();

            // time and vehicle page
            TimeAndVehiclePageTest timeAndVehiclePageTest = new TimeAndVehiclePageTest(driver);
            timeAndVehiclePageTest.testAutomateTheTimeAndVehiclePage();

            // order details page
            OrderDetailsPageTest orderDetailsPageTest = new OrderDetailsPageTest(driver);
            orderDetailsPageTest.testAutomateTheOrderDetailsPage();

        } catch (Exception e) {
            // handle other exceptions
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

    @BeforeSuite
    public static void openMobileApp() throws MalformedURLException {

        // set the capabilities for the application on android
        DesiredCapabilities cap = new DesiredCapabilities();
        cap.setCapability("appium:deviceName", "Galaxy C9 Pro");
        cap.setCapability("appium:udid", "479bb807");
        cap.setCapability("appium:platformName", "Android");
        cap.setCapability("appium:platformVersion", "8.0.0");
        cap.setCapability("appium:automationName", "uiAutomator2");
        cap.setCapability("appium:appPackage", "hk.gogovan.GoGoVanClient2.staging");
        cap.setCapability("appium:appActivity", "hk.gogovan.clientapp.RootActivity");

        URL url = new URL("http://127.0.0.1:4723/");
        driver = new AppiumDriver(url,cap);

        System.out.println("Application started!");
    }

    @AfterSuite
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            System.out.println("Driver closed.");
        }
    }

}
