package org.CATests.pageObjects.android.tests;

import io.appium.java_client.AppiumDriver;
import org.testng.annotations.Test;
import org.CATests.pageObjects.android.HomePage;
import static org.testng.Assert.assertTrue;

public class HomePageTest {

    private AppiumDriver driver;

    public HomePageTest(AppiumDriver driver) {
        this.driver = driver;
    }

    // function to automate the home page (clicking on the transport button)
    @Test
    public void testAutomateTheHomePage() {
        HomePage homePage = new HomePage(driver);
        boolean isClicked = homePage.clickTransportButton();
        assertTrue(isClicked, "failed to click on the transport button.");
        System.out.println("Going to Transport Page: Success");
    }

}
